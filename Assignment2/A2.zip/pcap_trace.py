import pcapy
import dpkt
import socket
import datetime
import sys
if(len(sys.argv)>=2):
    filenamef = sys.argv[1]
else:
    filename = 'sample-capture-file.pcap'
file = open(filename,'rb')
pcap = dpkt.pcap.Reader(file)
#Global Variabes
counter=0
ipcounter=0
num_of_reset_TCP_conn=0
num_of_conn_count=0
num_of_connections=0
num_of_complete_conn=0
#arrays to store incomplete connections
src_arr=[]
dst_arr=[]
sport_arr=[]
dport_arr=[]
#arrays to store all connections
src_ip_array=[]
dst_ip_array=[]
src_port=[]
dest_port=[]
#arrays to store complete TCP connection ip addr, port
complete_conn_src=[]
complete_conn_dest=[]
complete_sport=[]
complete_dport=[]
#
time_duration_arr=[]
pkts_arr=[]
window_size_arr=[]
rtt_arr=[]
ts_arr=[]
def check_duplicate(src,srcPort,dest,destPort):
    for i in range(len(src_port)):
        if((src==src_ip_array[i])&(dest==dst_ip_array[i])&(srcPort==src_port[i])&(destPort==dest_port[i])):
            return False;
    return True

#these two methods to find
def check_dst_src(src,dest,sport,dport):
    for i in range(len(src_arr)):
        if((dest==dst_arr[i]) & (src==src_arr[i])&(sport==sport_arr[i])&(dport==dport_arr[i])):
            complete_conn_src.append(src_arr[i])
            complete_conn_dest.append(dst_arr[i])
            complete_sport.append(sport_arr[i])
            complete_dport.append(dport_arr[i])
            del src_arr[i]
            del dst_arr[i]
            del dport_arr[i]
            del sport_arr[i]
            return True;
    return False
def check_src_dst(src,dest,sport,dport):
    for i in range(len(src_arr)):
        if((dest==src_arr[i]) & (src==dst_arr[i])&(sport==dport_arr[i])&(dport==sport_arr[i])):
            complete_conn_src.append(src_arr[i])
            complete_conn_dest.append(dst_arr[i])
            complete_sport.append(sport_arr[i])
            complete_dport.append(dport_arr[i])
            del src_arr[i]
            del dst_arr[i]
            del dport_arr[i]
            del sport_arr[i]
            return True;
    return False

def get_num_of_conn(pcap):
    for ts, pkt in pcap:
        #print('Timestamp: ', str(datetime.datetime.utcfromtimestamp(ts)))
        ts_arr.append(ts)
        global counter
        counter+=1
        eth=dpkt.ethernet.Ethernet(pkt)
        #ip_hdr = eth.data
        ip=eth.data
        ###get ip address in readable string###
        src_ip_addr = socket.inet_ntoa(ip.src)
        dst_ip_addr = socket.inet_ntoa(ip.dst)
        if eth.type!=dpkt.ethernet.ETH_TYPE_IP:
           continue

        tcp=ip.data
        '''tcp = ip.data
        print(tcp.sport)
        print(tcp.dport)'''
        #if is a TCP packet
        if ip.p==dpkt.ip.IP_PROTO_TCP:
            tcp = ip.data
            if((tcp.flags&dpkt.tcp.TH_RST)!=0):
                global  num_of_reset_TCP_conn
                num_of_reset_TCP_conn+=1
            if(((tcp.flags&dpkt.tcp.TH_SYN)!=0)&((tcp.flags&dpkt.tcp.TH_ACK)==0)):
                global num_of_connections
                num_of_connections+=1
                if check_duplicate(src_ip_addr,tcp.sport,dst_ip_addr,tcp.dport):
                    src_ip_array.append(src_ip_addr)
                    src_port.append(tcp.sport)
                    dst_ip_array.append(dst_ip_addr)
                    dest_port.append(tcp.dport)
                    src_arr.append(src_ip_addr)
                    sport_arr.append(tcp.sport)
                    dst_arr.append(dst_ip_addr)
                    dport_arr.append(tcp.dport)
            if((tcp.flags&dpkt.tcp.TH_FIN)!=0):
                src = src_ip_addr
                dst = dst_ip_addr
                if(check_src_dst(src,dst,tcp.sport,tcp.dport) or check_dst_src(src,dst,tcp.sport,tcp.dport)):
                    global num_of_complete_conn
                    num_of_complete_conn += 1
def check_the_complete_conn(src_ip,src_port,des_ip,dest_port):
    for i in range(len(complete_conn_src)):
        if((complete_conn_src[i]==src_ip)&(complete_sport[i]==src_port)&(complete_conn_dest[i]==des_ip)&(complete_dport[i]==dest_port)):
            return True
    return False

def get_packet(src_ip,src_port,des_ip,des_port,filename,num,f):
    f.write("Connection "+str(num)+"\n")
    start_time=0
    end_time=0
    pcap = get_data(filename)
    num_of_pkt_src_dest=0
    num_of_pkt_dest_src=0
    byte_of_data_src_dest=0
    byte_of_data_dest_src=0
    num_of_SIN=0
    num_of_FIN=0
    window_size=0;
    for ts, pkt in pcap:
        eth = dpkt.ethernet.Ethernet(pkt)
        ip = eth.data
        src_ip_addr = socket.inet_ntoa(ip.src)
        dst_ip_addr = socket.inet_ntoa(ip.dst)
        if ip.p == dpkt.ip.IP_PROTO_TCP:
            tcp=ip.data
            temp = tcp.win
            #print(tcp.win)
            if(check_the_complete_conn(src_ip,src_port,des_ip,des_port)):
                if((src_port==tcp.sport)&(src_ip==src_ip_addr)&(des_port==tcp.dport)&(des_ip==dst_ip_addr)):
                    if((tcp.flags&dpkt.tcp.TH_SYN)!=0):
                        start_time=ts
                        num_of_SIN+=1
                if((src_port==tcp.dport)&(src_ip==dst_ip_addr)&(des_port==tcp.sport)&(des_ip==src_ip_addr)):
                    if((tcp.flags&dpkt.tcp.TH_SYN)!=0):
                        num_of_SIN+=1
                if((src_port==tcp.sport)&(src_ip==src_ip_addr)&(des_port==tcp.dport)&(des_ip==dst_ip_addr)):
                    #print(tcp.win)
                    byte_of_data_src_dest=byte_of_data_src_dest+ip.len
                    num_of_pkt_src_dest+=1
                    window_size = window_size+temp
                    if((tcp.flags&dpkt.tcp.TH_FIN)!=0):
                        end_time=ts
                        num_of_FIN+=1
                if ((src_port == tcp.dport) & (src_ip == dst_ip_addr) & (des_port == tcp.sport) & (des_ip == src_ip_addr)):
                    window_size = window_size+temp
                    #print(tcp.win)
                    byte_of_data_dest_src = byte_of_data_dest_src + ip.len
                    num_of_pkt_dest_src += 1
                    if ((tcp.flags & dpkt.tcp.TH_FIN) != 0):
                        end_time = ts
                        num_of_FIN+=1
            else:
                if ((src_port == tcp.sport) & (src_ip == src_ip_addr) & (des_port == tcp.dport) & (
                        des_ip == dst_ip_addr)):
                    if ((tcp.flags & dpkt.tcp.TH_SYN) != 0):
                        num_of_SIN += 1
                if ((src_port == tcp.dport) & (src_ip == dst_ip_addr) & (des_port == tcp.sport) & (
                        des_ip == src_ip_addr)):
                    if ((tcp.flags & dpkt.tcp.TH_SYN) != 0):
                        num_of_SIN += 1
                if ((src_port == tcp.sport) & (src_ip == src_ip_addr) & (des_port == tcp.dport) & (
                        des_ip == dst_ip_addr)):
                    if ((tcp.flags & dpkt.tcp.TH_FIN) != 0):
                        num_of_FIN += 1
                if ((src_port == tcp.dport) & (src_ip == dst_ip_addr) & (des_port == tcp.sport) & (
                        des_ip == src_ip_addr)):
                    num_of_pkt_dest_src += 1
                    if ((tcp.flags & dpkt.tcp.TH_FIN) != 0):
                        num_of_FIN += 1
    str_of_status="S"+str(num_of_SIN)+"F"+str(num_of_FIN)
    f.write("Source Address: "+src_ip+"\n")
    f.write("Destination Address: "+des_ip+"\n")
    f.write("Source Port: "+str(src_port)+"\n")
    f.write("Destination Port: "+str(des_port)+"\n")
    f.write("Status: "+str_of_status+"\n")
    if(check_the_complete_conn(src_ip,src_port,des_ip,des_port)):
        const_time = ts_arr[0]

        window_size_arr.append(window_size);
        duration = end_time-start_time
        time_duration_arr.append(duration)
        num_of_total_pkts=num_of_pkt_src_dest+num_of_pkt_dest_src
        pkts_arr.append(num_of_total_pkts)
        total_byte = byte_of_data_dest_src+byte_of_data_src_dest
        #f.write('Start time: '+ str(datetime.datetime.utcfromtimestamp(start_time))+"\n")
        #f.write('End time: '+ str(datetime.datetime.utcfromtimestamp(end_time))+"\n")
        f.write('Start time: ' + str(start_time-const_time) + "\n")
        f.write('End time: ' + str(end_time-const_time) + "\n")
        f.write("Duration: "+ str(duration)+"\n")
        f.write("Number of packets sent from Source to Destination: "+str(num_of_pkt_src_dest)+"\n")
        f.write("Number of packets sent from Destination to Source: "+str(num_of_pkt_dest_src)+"\n")
        f.write("Total num of packets: "+str(num_of_total_pkts)+"\n")
        f.write("Number of data bytes sent from Source to Destination: "+str(byte_of_data_src_dest)+"\n")
        f.write("Number of data bytes sent form Destination to Source: "+str(byte_of_data_dest_src)+"\n")
        f.write("Total byte of data: "+str(total_byte)+"\n")
def get_data(filename):
    file = open(filename,'rb')
    pcap = dpkt.pcap.Reader(file)

    return pcap

get_num_of_conn(pcap)
#print("Total number of packets in the pcap file: ", counter)
#print("Total number of tcp connections: ", num_of_connections)
#print("Total number of complete connections: ", num_of_complete_conn)
outputFile = open("Output.txt",'w')
outputFile.write("Total number of connections: "+str(len(src_port))+"\n")
outputFile.write("________________________________________________________\n")
file.close()

#print("Total packets of 1201: ",get_data(1,1201,2,2,pcap))
#(1,1203,1,1,filename)
for i in range(len(src_ip_array)):
    get_packet(src_ip_array[i],src_port[i],dst_ip_array[i],dest_port[i],filename,i+1,outputFile)
    outputFile.write("\n")
outputFile.write("________________________________________________________\n")
outputFile.write("Total number of complete TCP connections: "+str(len(complete_conn_src))+"\n")
outputFile.write("Number of reset TCP connections: "+str(num_of_reset_TCP_conn)+"\n")
outputFile.write("Number of TCP connections that were still open when the trace capture ended: "+str(len(src_arr))+"\n")
outputFile.write("________________________________________________________\n")
min_time_duration = time_duration_arr[0]
max_time_duration = time_duration_arr[0]
sum_time_duration=0
for i in range(len(time_duration_arr)):
    if(time_duration_arr[i]>max_time_duration):
        max_time_duration=time_duration_arr[i]
    if(time_duration_arr[i]<min_time_duration):
        min_time_duration=time_duration_arr[i]
    sum_time_duration=sum_time_duration+time_duration_arr[i]
mean_time_duration = sum_time_duration/len(time_duration_arr)

min_packets = pkts_arr[0]
max_packets = pkts_arr[0]
sum_packets = 0
for i in range(len(pkts_arr)):
    if(pkts_arr[i]>max_packets):
        max_packets = pkts_arr[i]
    if(pkts_arr[i]<min_packets):
        min_packets = pkts_arr[i]
    sum_packets = sum_packets+pkts_arr[i]
mean_pkts = sum_packets/len(pkts_arr)

rtt_arr=[]
for i in range(len(time_duration_arr)):
    temp = time_duration_arr[i]/pkts_arr[i]
    rtt_arr.append(temp)
min_rtt = rtt_arr[0]
max_rtt = rtt_arr[0]
sum_rtt=0
for i in range(len(rtt_arr)):
    if(rtt_arr[i]>max_rtt):
        max_rtt=rtt_arr[i]
    if(rtt_arr[i]<min_rtt):
        min_rtt=rtt_arr[i]
    sum_rtt = sum_rtt+rtt_arr[i]
mean_rtt = sum_rtt/len(rtt_arr)

min_win_size=window_size_arr[0]
max_win_size=window_size_arr[0]
sum_win_size = 0
for i in range(len(window_size_arr)):
    if(window_size_arr[i]>max_win_size):
        max_win_size=window_size_arr[i]
    if(window_size_arr[i]<min_win_size):
        min_win_size=window_size_arr[i]
    sum_win_size = sum_win_size+window_size_arr[i]
mean_win_size = sum_win_size/len(window_size_arr)

outputFile.write("Minimum time duration: "+str(min_time_duration)+"\n")
outputFile.write("Mean time duration: "+str(mean_time_duration)+"\n")
outputFile.write("Maximum time duration: "+str(max_time_duration)+"\n")
outputFile.write("\n")
outputFile.write("Minimum RTT value: "+str(min_rtt)+"\n")
outputFile.write("Mean RTT value: "+str(mean_rtt)+"\n")
outputFile.write("Maximum RTT value: "+str(max_rtt)+"\n")
outputFile.write("\n")
outputFile.write("Minimum number of packets including both send/received: "+str(min_packets)+"\n")
outputFile.write("Mean number of packets including both send/received: "+str(mean_pkts)+"\n")
outputFile.write("Maximum number of packets including both send/received: "+str(max_packets)+"\n")
outputFile.write("\n")
outputFile.write("Minimum receive window size including both send/received: "+str(min_win_size)+"\n")
outputFile.write("Mean receive window size including both send/received: "+str(mean_win_size)+"\n")
outputFile.write("Maximum receive window size including both send/received: "+str(max_win_size)+"\n")

