To run the code:
1. Python 3 or upper needs to be installed
2. The dpkt module in python library needs to be installed
3. The "sample-capture-file.pcap" is the default test pcap file, also you can input your own test pcap file,
please make sure the input file must be .pcap file, the program doesn't work on file without .pcap
4. After the program is executed, then go to the directory where you run the program, the output will be printed in a text file called output.txt.
the output in output.txt is strictly formatted as required
5. Be aware of rrt, some of them may not be correct.