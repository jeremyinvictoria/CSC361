1. The SmartWebClient is an application used on the client side which can tell you if the 
web host supports HTTPS and what HTTP version it supports and captures Cookies.
2. To run the program, you need to have Python3.0 or upper version installed.
3. Type python3 SmartWebClient.py on terminal
4. The program will require you to enter a website with format: <www.aliasname.com> on the prompt
5. The program doesn't work on "www.mcgill.ca", it will give you a HANDSHAKE FAILED exception,
so please do not try this site on the program.
6. For some websites that support HTTP/2,for example "www.akamai.com" and "www.python.org", since the 
mechanism of web server, you will not get cookies from it, but you can still test to see
what HTTP version it supports and if it supports HTTPS.
7. "https://www.bbc.com" supports HTTP/2, but it will give you a redirection to "http://www.bbc.com"
which does not support HTTP/2, so it's quite tricky to figure out wether it supports HTTP/2
or it supports HTTPS. You can try this one, but please be AWARE of the confusion.