import socket
import ssl
import re
import h2.connection
import sys
if(len(sys.argv)>=2):
	server_addr = sys.argv[1]
else:
	server_addr = input("Please enter a website: ")
http_port = 80
http_version = "1.1"
https_port=443
print("website: "+server_addr)
https2_request = "GET / HTTP/1.1\r\nHost: "+server_addr+\
                "\r\nConnection: Upgrade, HTTP2-Settings\r\nUpgrade: h2c\r\nHTTP2-Settings:\r\n\r\n"
http_version_supported = ""
https_supported=""
final_cookie = []
#
#
#
def establish_tcp_connection(server):
    return socket.create_connection((server, 443))
def get_http2_ssl_context():
    ctx = ssl.create_default_context(purpose=ssl.Purpose.SERVER_AUTH)

    ctx.options |= (
        ssl.OP_NO_SSLv2 | ssl.OP_NO_SSLv3 | ssl.OP_NO_TLSv1 | ssl.OP_NO_TLSv1_1
    )

    ctx.options |= ssl.OP_NO_COMPRESSION

    ctx.set_ciphers("ECDHE+AESGCM:ECDHE+CHACHA20:DHE+AESGCM:DHE+CHACHA20")

    ctx.set_alpn_protocols(["h2", "http/1.1"])
    try:
        ctx.set_npn_protocols(["h2", "http/1.1"])
    except NotImplementedError:
        pass
    return ctx

def negotiate_tls(tcp_conn, context,server):
    flag = 1

    try:
        tls_conn = context.wrap_socket(tcp_conn, server_hostname=server)

        negotiated_protocol = tls_conn.selected_alpn_protocol()
        if negotiated_protocol is None:
            negotiated_protocol = tls_conn.selected_npn_protocol()
        if negotiated_protocol != "h2":
        #raise RuntimeError("Didn't negotiate HTTP/2!")
            flag = 0
            return flag
        #return tls_conn
    except socket.error as e:
        print("handshake failed.")
        exit(0)
    except socket.gaierror as e:
        print("Invalid host.")
    return flag

#
#
#

def separate_full_response(str):
    curl = "\r\n\r\n"
    end_of_response_line = str.find(curl)
    get_reponse_line = ""
    for i in range(0, end_of_response_line):
        get_reponse_line = get_reponse_line + str[i]
    return get_reponse_line

def get_full_http_response_line(s,server_addr):
    http_request = "GET / HTTP/" + http_version + "\r\nHost: " + server_addr + "\r\nConnection: Close\r\n\r\n"
    s.connect((server_addr, http_port))
    s.send(http_request.encode())
    full_response = ""
    while True:
        response = s.recv(1024)
        response_in_string = response.decode("utf-8", errors="replace")
        full_response = full_response + response_in_string
        #    print(response_in_string)
        if not response: break

    s.close()
    return full_response

def get_full_https_response_line(s,context,server_addr):
    https_request = "GET / HTTP/" + http_version + "\r\nHost: " + server_addr + "\r\nConnection: Close\r\n\r\n"
    full_response = ""
    try:
        ss = context.wrap_socket(s, server_hostname=server_addr)
        ss.connect((server_addr,https_port))
        ss.send(https_request.encode("utf-8"))

        while True:
            response = ss.recv(1024)
            response_in_string = response.decode("utf-8", errors="replace")
            full_response = full_response + response_in_string
            if not response: break
        ss.close()
    except socket.gaierror as e:
        print("Invalid host address")
    except socket.error as e:
        print("Check your Internet Connection")
    return full_response
#used for send redirectional request
def get_full_https2_response_line(s,context,content,server_addr):
    https_request = "GET "+content+" HTTP/" + http_version + "\r\nHost: " + server_addr + "\r\nConnection: Close\r\n\r\n"
    full_response = ""
    try:
        ss = context.wrap_socket(s, server_hostname=server_addr)
        ss.connect((server_addr,https_port))
        ss.send(https_request.encode("utf-8"))

        while True:
            response = ss.recv(1024)
            response_in_string = response.decode("utf-8", errors="replace")
            full_response = full_response + response_in_string
            if not response: break
        ss.close()
    except socket.gaierror as e:
        print("Invalid host address")
    except socket.error as e:
        print("Check your Internet Connection")
    return full_response
def get_redir_address(result):
    new_address_array=""

    Location_start = result.find("Location")
    i = Location_start+10
    new_address = ""
    while(result[i]!='\r'):
        new_address = new_address+result[i]
        i = i+1
    new_address_array = new_address.split('/')
    return new_address_array
def getCookies(response):
    modified_response = response+'\n'
    indexes = [m.start() for m in re.finditer('Set-Cookie', modified_response)]
    Cookies_array = []
    for i in indexes:
        start_pos = i + 12
        cookie_string = ""
        while (modified_response[start_pos] != '\n'):
            cookie_string = cookie_string + modified_response[start_pos]
            start_pos = start_pos + 1
        Cookies_array.append(cookie_string);
    return Cookies_array;
#https_response = get_full_https_response_line(s,context,server_addr)
#https_result = separate_full_response(https_response)
#print(https_result)

#print("new address is :"+get_redir_address(https_result))
#s2 = socket.socket(socket.AF_INET,socket.SOCK_STREAM)

#second_request_send = separate_full_response(get_full_https_response_line(s2,context,get_redir_address(https_result)))
#print(getCookies(second_request_send))



def main():
    # Step 1: Set up your TLS context.
    context = get_http2_ssl_context()
    # Step 2: Create a TCP connection.
    connection = establish_tcp_connection(server_addr)
    # Step 3: Wrap the connection in TLS and validate that we negotiated HTTP/2
    flag = negotiate_tls(connection, context,server_addr)
    if(flag==0):#webserver does not support http/2
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        https_context = ssl.SSLContext(ssl.PROTOCOL_SSLv23)
        response = separate_full_response(get_full_https_response_line(s, https_context,server_addr))

        #print(response)
        if(response.find("HTTP/1.1")>=0):#support http/1.1
            if (response.find("301")>=0 and response.find("301")<=15) or (response.find("302")>=0 and response.find("302")<=15):
                new_address = get_redir_address(response)

                if(new_address[0].find("https")>=0):
                    #print("https supported")
                    global http_version_supported
                    global https_supported
                    global final_cookie
                    https_supported = "yes"
                    http_version_supported = "HTTP/1.1"
                    new_server_addr = new_address[2]
                    #print(new_address)
                    #print(len(new_address))
                    #print("new address is: "+new_address[2])
                    s2 = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
                    content = ""
                    for i in range(3,len(new_address)):
                        content = content+'/'+new_address[i]
                    #print("CONTENT is: "+content)
                    second_respone = separate_full_response(get_full_https2_response_line(s2,https_context,content,new_server_addr))
                    #print(second_respone)
                    #print(getCookies(second_respone))
                    http_version_supported = "HTTP/1.1"
                    final_cookie = (getCookies(second_respone))
                else:
                    #print("http supported")
                    https_supported = "no"
                    http_version_supported = "HTTP/1.1"
                    #print(new_address[2])
                    s2 = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                    content = ""
                    for i in range(3, len(new_address)):
                        content = content + '/' + new_address[i]
                    #print("CONTENT is: " + content)
                    second_respone = separate_full_response(get_full_http_response_line(s2,new_address[2]))
                    #print(second_respone)
                    #assign the value to gobal variable
                    final_cookie = (getCookies(second_respone))
            if(response.find("404")>0 and response.find("404")<=15):
                print("page not found!")
                exit(0)
            if(response.find(("505"))>=0 and response.find("505")<=15):
                print("server error!")
                exit(0)
            if(response.find("200")>0 and response.find("200")<=15):
                http_version_supported = "HTTP/1.1"
                https_supported="yes"
                final_cookie = (getCookies(response))
    else:#webserver supports http/2
        http_version_supported = "HTTP/2"
        https_supported = "yes"
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        https_context = ssl.SSLContext(ssl.PROTOCOL_SSLv23)
        response = separate_full_response(get_full_https_response_line(s, https_context, server_addr))
        #print(response)
        if (response.find("HTTP/1.1") >= 0):  # support http/1.1
            if (response.find("301") >= 0 and response.find("301") <= 15) or (
                    response.find("302") >= 0 and response.find("302") <= 15):
                new_address = get_redir_address(response)

                if (new_address[0].find("https") >= 0):
                    # print("https supported")
                    #global http_version_supported
                    #global https_supported
                    #global final_cookie
                    #https_supported = "yes"
                    #http_version_supported = "HTTP/1.1"
                    new_server_addr = new_address[2]
                    # print(new_address)
                    # print(len(new_address))
                    # print("new address is: "+new_address[2])
                    s2 = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                    content = ""
                    for i in range(3, len(new_address)):
                        content = content + '/' + new_address[i]
                    # print("CONTENT is: "+content)
                    second_respone = separate_full_response(
                        get_full_https2_response_line(s2, https_context, content, new_server_addr))
                    # print(second_respone)
                    # print(getCookies(second_respone))
                    http_version_supported = "1.1"
                    final_cookie = (getCookies(second_respone))
                else:
                    # print("http supported")
                    https_supported = "no"
                    #http_version_supported = "HTTP/1.1"
                    #print(new_address[2])
                    s2 = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                    content = ""
                    for i in range(3, len(new_address)):
                        content = content + '/' + new_address[i]
                    # print("CONTENT is: " + content)
                    second_respone = separate_full_response(get_full_http_response_line(s2, new_address[2]))
                    # print(second_respone)
                    # assign the value to gobal variable
                    final_cookie = (getCookies(second_respone))
            if (response.find("200") > 0 and response.find("200") <= 15):
                #http_version_supported = "HTTP/1.1"
                #https_supported = "yes"
                print("line 275: "+response)
                final_cookie = (getCookies(response))
        #print("hello")
main()

print("1. Support of HTTPS: "+https_supported)
print("2. The newest HTTP versions that the web server supports: "+http_version_supported)
print("3. List of Cookies: ")
for i in final_cookie:
    print(i)
